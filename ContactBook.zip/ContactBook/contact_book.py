import json
import os

# File to store contacts
FILE_NAME = "contacts.txt"

# Load contacts from file if it exists
if os.path.exists(FILE_NAME):
    with open(FILE_NAME, "r") as file:
        try:
            contacts = json.load(file)
        except json.JSONDecodeError:
            contacts = {}
else:
    contacts = {}

# Save contacts to file
def save_contacts():
    with open(FILE_NAME, "w") as file:
        json.dump(contacts, file, indent=4)

# Add a contact
def add_contact():
    name = input("Enter name: ")
    phone = input("Enter phone number: ")
    email = input("Enter email: ")
    address = input("Enter address: ")
    contacts[name] = {"phone": phone, "email": email, "address": address}
    save_contacts()
    print(f"Contact '{name}' added successfully!\n")

# View all contacts
def view_contacts():
    if not contacts:
        print("No contacts found.\n")
        return
    print("Contact List:")
    for name, info in contacts.items():
        print(f"Name: {name}, Phone: {info['phone']}")
    print()

# Search contact by name or phone
def search_contact():
    query = input("Enter name or phone to search: ")
    found = False
    for name, info in contacts.items():
        if query.lower() in name.lower() or query in info['phone']:
            print(f"Name: {name}, Phone: {info['phone']}, Email: {info['email']}, Address: {info['address']}")
            found = True
    if not found:
        print("No contact found.\n")
    print()

# Update a contact
def update_contact():
    name = input("Enter the name of the contact to update: ")
    if name in contacts:
        phone = input(f"Enter new phone ({contacts[name]['phone']}): ")
        email = input(f"Enter new email ({contacts[name]['email']}): ")
        address = input(f"Enter new address ({contacts[name]['address']}): ")
        contacts[name] = {
            "phone": phone or contacts[name]['phone'],
            "email": email or contacts[name]['email'],
            "address": address or contacts[name]['address']
        }
        save_contacts()
        print(f"Contact '{name}' updated successfully!\n")
    else:
        print("Contact not found.\n")

# Delete a contact
def delete_contact():
    name = input("Enter the name of the contact to delete: ")
    if name in contacts:
        del contacts[name]
        save_contacts()
        print(f"Contact '{name}' deleted successfully!\n")
    else:
        print("Contact not found.\n")

# Main menu
def main():
    while True:
        print("=== Contact Book ===")
        print("1. Add Contact")
        print("2. View Contacts")
        print("3. Search Contact")
        print("4. Update Contact")
        print("5. Delete Contact")
        print("6. Exit")
        
        choice = input("Enter your choice (1-6): ")
        print()
        
        if choice == '1':
            add_contact()
        elif choice == '2':
            view_contacts()
        elif choice == '3':
            search_contact()
        elif choice == '4':
            update_contact()
        elif choice == '5':
            delete_contact()
        elif choice == '6':
            print("Exiting Contact Book. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.\n")

if __name__ == "__main__":
    main()
