import tkinter as tk
from tkinter import messagebox

tasks = []

def add_task():
    task = entry.get()
    if task:
        listbox.insert(tk.END, task)
        entry.delete(0, tk.END)
    else:
        messagebox.showwarning("Warning", "Please enter a task.")

def delete_task():
    try:
        index = listbox.curselection()[0]
        listbox.delete(index)
    except:
        messagebox.showwarning("Warning", "Select a task to delete.")

def mark_complete():
    try:
        index = listbox.curselection()[0]
        task = listbox.get(index) + " ✔"
        listbox.delete(index)
        listbox.insert(index, task)
    except:
        messagebox.showwarning("Warning", "Select a task first.")

root = tk.Tk()
root.title("To-Do List App")
root.geometry("400x400")

entry = tk.Entry(root, width=30)
entry.pack(pady=10)

btn_add = tk.Button(root, text="Add Task", width=20, command=add_task)
btn_add.pack()

listbox = tk.Listbox(root, width=40, height=15)
listbox.pack(pady=10)

btn_complete = tk.Button(root, text="Mark Complete", width=20, command=mark_complete)
btn_complete.pack()

btn_delete = tk.Button(root, text="Delete Task", width=20, command=delete_task)
btn_delete.pack()

root.mainloop()
