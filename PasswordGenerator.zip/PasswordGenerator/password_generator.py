import random
import string

def generate_strong_password(length):
    if length < 4:
        return "Password length should be at least 4 for security."

    # Define character sets
    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    digits = string.digits
    symbols = string.punctuation

    # Ensure at least one character from each set
    password = [
        random.choice(lower),
        random.choice(upper),
        random.choice(digits),
        random.choice(symbols)
    ]

    # Fill the remaining length with random choices from all sets
    if length > 4:
        all_chars = lower + upper + digits + symbols
        password += random.choices(all_chars, k=length-4)

    # Shuffle the list to randomize character positions
    random.shuffle(password)

    # Convert list to string
    return ''.join(password)

# User input
try:
    length = int(input("Enter the desired password length: "))
    generated_password = generate_strong_password(length)
    print("Generated Password:", generated_password)
except ValueError:
    print("Please enter a valid number for the length.")
